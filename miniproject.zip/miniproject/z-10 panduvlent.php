<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MahaTravel-booking</title>
  <link rel="icon" type="image/x-icon" href="images/India gate logo - small size.png">
  <link rel="stylesheet" href="css/booking.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
  <table>
    <td class="contaner2">
      <h1>panduvlent (from Nashik)</h1>
      <h4 style="color: blue;">* Private Tour &nbsp; * 5D/4N &nbsp; * Ex-Pune &nbsp; <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span>
        <span class="fa fa-star checked"></span> &nbsp; 4.9/5 </h4>
      
      
    <div class="borders">
  <img src="images/img-10.jpg" width="850px" height="400px">
    </div> 
    </td>
  
    <td class="contaner">
  <form action="reservation.php" method="post">
   <div>
    &emsp;
    <h4 class="origPriceAdult" style="display:inline-block; text-decoration: line-through; color: #A0A0A0;">₹16563</h4>
    <h2 class="tourPriceAdult" style="display:inline-block;">₹13250</h2>
    <span class="destDesc" style="display:inline-block;padding-left: 15px;">(Per Adult)</span>
    &emsp; &emsp; &emsp; 
    <span class="destDesc2 iconStay" style="display: inline-block;padding-right:15px;"><img width="22" src="images/icon-stay.png" style="margin-left: 3px;"><br>Stay</span>
    <span class="destDesc2 iconStay" style="display: inline-block;padding-right:15px;"><img width="22" src="images/icon-getaway.png" style="margin-left: 3px;"><br>Travel</span>
    <span class="destDesc2 iconStay" style="display: inline-block;padding-right:15px;"><img width="22" src="images/icon-place.png" style="margin-left: 3px;"><br>Sight</span>
    <span class="destDesc2 iconStay" style="display: inline-block;padding-right:15px;"><img width="22" src="images/icon-food2.png" style="margin-left: 3px;"><br>Food</span>

  </div>

  <hr>
    <div class="elem-group inlined">
      <label for="adult">Adults</label>
      <input type="number" id="adult" name="total_adults" placeholder="2" min="1" required>
    </div>
    <div class="elem-group inlined">
      <label for="child">Children</label>
      <input type="number" id="child" name="total_children" placeholder="2" min="0" required>
    </div>
    <div class="elem-group inlined">
      <label for="checkin-date">Check-in Date</label>
      <input type="date" id="checkin-date" name="checkin" required>
    </div>
    <div class="elem-group inlined">
      <label for="checkout-date">Check-out Date</label>
      <input type="date" id="checkout-date" name="checkout" required>
    </div>
    <div class="elem-group">
      <label for="room-selection">Vehicle</label>
      <select id="room-selection" name="room_preference" required>
          <option value="">Choose a Travel Mode</option>
          <option value="connecting">Seden-AC</option>
          <option value="adjoining">SUV-AC</option>
      </select>
    </div>
    <hr>
    <br>
    <center><a class="btn" href="pay.php">Book The Trip</a></center>
  </form>
</td>
</table>
&emsp;&emsp;
<center>
<h2 style="color: #FF0000;">
<img height="25" src="images/alert-red2.jpg">&nbsp; Please check 
<a href="policy.html" id="lnkPolicy">Booking Policy</a> for COVID-19 related guidelines</h2>
</center>
  &emsp;&emsp;

  <div class="Ani">
  <h2><center>
  <a class="Aditya" href="#Interior"><img width="22" src="images/ico-order_plan1.png" style="margin: 3px;">&nbsp; Interior</a>
  <a class="Aditya" href="#Hotel Details"><img width="22" src="images/icon-stay.png" style="margin: 3px;">&nbsp; Hotel Details</a>
  <a class="Aditya" href="#Inclusions/Exclusions"><img width="22" src="images/ico-order_plan2.png" style="margin: 3px;">&nbsp; Inclusions/Exclusions</a>
  </h2></center>
  </div>

  &emsp13;
<h2><center><a name="Interior">Interior</a></center></h2>
<hr>
<h3>Day 1: Start at 7 AM from Pune - Travel to Mahabaleshwar & Mahabaleshwar Sightseeing</h3>
<ul>
<li>Krishnabai Temple / Krishna Devi Temple</li>
<li>Mahabaleshwar Mandir</li>
<li>Panch Ganga / Panchganga Temple</li>
<li>Elphinstone Point</li>
<li>Arthur Seat Point</li>
<li>ombay Point / Sunset Point</li>
</ul>
<h3>Day 2: Start at 9 AM - Mahabaleshwar Sightseeing</h3>
<ul>
<li>Venna Dam / Lake</li>
<li>Elephant's Head Point & Kate's Point</li>
<li>Lingmala Waterfall</li>
<li>Mapro Garden</li>
</ul>
<h3>Day 3: Start at 8 AM - Visit Pratapgad & Travel to Ratnagiri</h3>
<ul>
<li>Pratapgad Fort / Pratapgarh Fort</li>
</ul>
<h3>Day 4: Start at 9 AM - Ratnagiri Sightseeing & Travel to Ganpatipule</h3>
<ul>
<li>Thiba Palace / Thibaw Palace</li>
<li>Marine Aquarium & Museum</li>
<li>Ratnadurg Fort</li>
<li>Mandavi Beach</li>
<li>Aare Ware Beach</li>
</ul>
<h3>Day 5: Start at 9 AM - Ganpatipule Sightseeing & Travel to Pune</h3>
<ul>
<li>Swayambhu Ganapati Temple</li>
<li>Ganpatipule Beach</li>
<li>Prachin Konkan Museum</li>
<li>Reach Pune by around 10 PM</li>
</ul>
NOTE: Waterfalls in Mahabaleshwar / Panchgani / Lonavala would be dry in summer season (monsoon & post-monsoon is best season)
** Few places may be closed due to Covid. We will try to provide alternate sightseeing in such cases.

&emsp13;
<div>
<h2><center><a name="Hotel Details">Hotel Details</a></center></center></h2>
<hr>
<h4><center>Below are the primary hotels for your stay</center></h4>


<table class="padd" style="width: 100%; text-align: center;">
  <td class="ht">
    <h3>2-Star</h3>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star"></span>
    <span class="fa fa-star"></span>
    <span class="fa fa-star"></span>

    <h2>Mahabaleshwar (2N)</h2>
    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&selectedproperty=2229901&city=3609&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Hotel J's Excellency</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Deluxe Room Non AC)</h3>
    <h3>(146 Reviews)</h3>

    <h2>Ratnagiri (1N)</h2>
    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&selectedproperty=646960&city=114635&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Hotel Mathura Executive</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Superior Eoom AC)</h3>
    <h3>(42 Reviews)</h3>

    <h2>Ganpatipule (1N)</h2>
    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&city=102462&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Hotel Pritysangam</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Non AC Room)</h3>
    <h3>(30 Reviews)</h3>

  </td>
  <td class="ht">
    <h3>3-Star</h3>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star"></span>
    <span class="fa fa-star"></span>

    <h2>Mahabaleshwar (2N)</h2>
    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&city=3609&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Saket Plaza</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Luxury Room AC)</h3>
    <h3>(300 Reviews)</h3>

    <h2>Ratnagiri (1N)</h2>
    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&selectedproperty=646960&city=114635&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Hotel Sangam Regency</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Deluxe Room AC)</h3>
    <h3>(42 Reviews)</h3>

    <h2>Ganpatipule (1N)</h2>
    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&selectedproperty=941914&city=114635&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Nakshatra Beach Resort</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Emerald Deluxe AC)</h3>
    <h3>(175 Reviews)</h3>
    
  </td>
  <td class="ht">
    <h3>4-Star</h3>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star checked"></span>
    <span class="fa fa-star"></span>

    <h2>Mahabaleshwar (2N)</h2>
    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&selectedproperty=735178&city=3609&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Bella Vista Resort</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Deluxe Room AC)</h3>
    <h3>(1427 Reviews)</h3>

    <h2>Ratnagiri (1N)</h2>

    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&selectedproperty=1292202&city=114635&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Kohinoor Samudra Beach Resort</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Executive Sea View Room)</h3>
    <h3>(75 Reviews)</h3>

    <h2>Ganpatipule (1N)</h2>

    <h3 style="color: rgb(55, 104, 194);"><a href="https://www.agoda.com/search?pcs=1&cid=1728432&city=102462&checkin=2022-12-02&checkout=2022-12-03&adults=1&children=0&rooms=1&los=1">Green Leaf Resort And Spa</a></h3>
    <h3><img width="88" src="images/4.0.png" style="margin: 3px;">&nbsp;(Executive Room AC)</h3>
    <h3>(440 Reviews)</h3>
  </td>
</table>
</div>


<div>
<h2><center><a name="Inclusions/Exclusions" >Inclusions/Exclusions</a></center></h2>
<hr>
<h3 style="color: #6f6f6f;">Inclusions</h3>
<ul>
<li>in selected category hotel (NA for Day Trips)</li> 
<li>Breakfast, except on Check-in Date (NA for Day Trips & Govt Properties)</li> 
<li>Sightseeing as per Itinerary by Private Cab</li> 
<li>Parking & Toll Charges</li> 
<li>Driver Allowance</li> 
<li>Inter-state Entry Tax, if applicable</li> 
<li>Ferry Tickets & Airport Transfers (for Andamans)</li> 
<li>Pickup & Drop from Your Origin City (Optional)</li> 
<li>Total fare includes GST</li> 
</ul>
<h3 style="color: #6f6f6f;">Exclusions</h3>
<ul>
  <li>Airfare</li> 
  <li>Lunch, Dinner, Snacks & Beverages</li> 
  <li>Entry Fees & Local Guide Charges</li> 
  <li>Activity Fees / Jeep Safari / Rafting / Adventure Sport Charges</li> 
  <li>Hotel Early Check-in / Late Check-out Charges, if applicable</li> 
  <li>Mandatory Gala Dinner for Christmas and New Year eve</li> 
  <li>Other items not mentioned in Inclusions</li> 
</ul>
<h3 style="color: #6f6f6f;">Optionals (arranged on request at additional cost)</h3>
<ul>
  <li>Homestays / Resorts / Choice of Hotels</li> 
  <li>Dinner</li> 
  <li>Tour guide (for selected destinations)</li> 
  <li>Honeymoon decoration, cake, candle light dinner (for selected destinations)</li> 
  <li>Airport Pickup & Drop (select by clicking Customize button while calculating price)</li> 
  <li>Visa assistance (for selected International destinations)</li> 
  <li>Travel insurance</li> 
</ul>
</div>
  <script src="js/booking.js"></script>
</body>
<footer>
  <img src="C:\Users\Adity\OneDrive\Documents\Mini Project 2\images\footer-bg.png" width="100%">
</footer>
</html>