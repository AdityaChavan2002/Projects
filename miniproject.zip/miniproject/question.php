<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Maha travel - FAQ</title>
<!-- web Icon  -->
<link rel="icon" type="image/x-icon" href="images/India gate logo - small size.png">

  <!-- swiper css link  -->
  <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <!-- custom css file link  -->
  <link rel="stylesheet" href="css/style.css">
  <div class="heading" style="background:url(images/header-bg-3.png) no-repeat">
    <h1>FAQ</h1>
 </div>
</head>
<style>
    .terms{
        padding: 70px;
        font-size: 1.5rem;
    }
</style>
<body>
  <div class="terms">
  <p>
  <h1>1. Why is Maharashtra famous for tourism?</h1><br><br>
    <p>The state boasts of thickly forested hills and valleys that are home to diverse flora and fauna, ancient caves, and a rich cultural heritage. Maharashtra is also known as the hub of the Indian entertainment industry or Bollywood as it is commonly called. The state is a major tourist destination in India.</p>
    <br><br><h1>2. What tourism potential does Maharashtra have?</h1><br><br>
    <p>
        The best time to visit Maharashtra is from the months of October to February. These months experience a typically hot and dry weather in most parts of Maharashtra but the eastern portion of the state might experience showers. Temperatures during the winter season varies between 12 degree Celsius to 25 degree Celsius.</p>
        <br><br><h1>3. Which is the first tourist district of Maharashtra?</h1><br><br>
        <p>
            Sindhudurg -
for its historical treasure and to enjoy the beach.
        </p>
        <br><br> <h1>4. Which is the tourism capital of Maharashtra?</h1><br><br>
           <p>
            Aurangabad
Aurangabad -'Tourism Capital of Maharashtra' is named after the Mughal Emperor Aurangzeb. The city is a tourism hub, surrounded by many historical monuments, including the caves of Ajanta and Ellora which are now UNESCO 'World Heritage Sites', as well as the famous Bibi ka Maqbara and Panchakki.</p>
<br><br> <h1>5. Who is the brand ambassador of Maharashtra tourism?</h1><br><br>
            <p>Sambhaji Raje Bhosale is the brand ambassador for Maharashtra Tourism. Salman Khan is the brand ambassador of BharatPe.</p>
            
</p>
  </div>
        </body>


<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="question.php"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="policy.php"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="terms.php"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +91 9325713728 </a>
         <a href="#"> <i class="fas fa-phone"></i> +91 8767810998 </a>
         <a href="mailto:"> <i class="fas fa-envelope"></i> adityachavan4142@gmail.com </a>
         <a href="https://www.google.com/maps/place/MGM's+College+Of+Engineering/@19.192287,77.2902639,14z/data=!4m10!1m2!2m1!1sMgm+college!3m6!1s0x3bd1d6fbe138ad81:0x9e88bbe86ec52250!8m2!3d19.1797222!4d77.3242529!15sCgtNZ20gY29sbGVnZVoNIgttZ20gY29sbGVnZZIBB2NvbGxlZ2WaASRDaGREU1VoTk1HOW5TMFZKUTBGblNVTkhhVFpwTlRSUlJSQULgAQA!16s%2Fg%2F1jkx8zyw3"> <i class="fas fa-map"></i> MGM's College Of Eng, Nanded </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://twitter.com/i/flow/login"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="https://www.instagram.com/"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="https://www.linkedin.com/login"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>Aditya.C & Aniket.D</span> | all rights reserved! </div>

</section>
</html>

<!-- footer section ends -->









<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>
</html>