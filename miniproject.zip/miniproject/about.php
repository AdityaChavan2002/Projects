<?php require('php\connection.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Maha travel - About</title>
   <!-- web Icon hot bar -->
   <link rel="icon" type="image/x-icon" href="images/India gate logo - small size.png">

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img width="44" src="images/India gate logo - small size.png" style="margin-left: 3px;">Maha travel&#174;</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a class="acctive" href="about.php">about</a>
      <a href="package.php">package</a>
      <a href="book.php">book</a>

      <?php
      if(isset($_SESSION['logged_in']) && $_SESSION['logged_in']==true)
      {
         echo"
            <a class='navbar'>
            $_SESSION[username] <a class='fas fa-power-off' style='font-size:26px' href='php\logout.php'></a>
            </a>
            ";
      }
      else
      {
         
         echo"
         
            <a class='btn' style='color: aliceblue;' onclick=\"popup('login-popup')\">login</a>
            <a class='btn' style='color: aliceblue;' onclick=\"popup('register-popup')\">sign up</a>
         </nav>
         ";
         
      }
   ?>
   <div id="menu-btn" class="fas fa-bars"></div>
   </div>
</section>
<!-- header section ends -->

<!--sign login start-->
<div class="popup-container" id="login-popup">
   <div class="popup">
     <form method="POST" action="php\login_register.php">
       <h2>
         <span style="font-size: 2rem;">USER LOGIN</span>
         <button style="font-size: 2rem;" type="reset" class="fas fa-bars fa-times" onclick="popup('login-popup')"></button>
       </h2>
       <input type="text" placeholder="E-mail or Username" name="email_username" required>
       <input type="password" placeholder="Password" name="password" required>
     <center><button type="submit" class="login-btn" name="login">LOGIN</button></center>  
     </form>
   </div>
 </div>

 <div class="popup-container" id="register-popup">
   <div class="register popup">
     <form method="POST" action="php\login_register.php">
       <h2>
         <span style="font-size: 2rem;">USER REGISTER</span>
         <button style="font-size: 2rem;" type="reset" class="fas fa-bars fa-times" onclick="popup('register-popup')"></button>
       </h2>
       <input type="text" pattern="[A-Za-z]{3}" placeholder="Full Name" name="fullname" required/>
       <input type="text" minlength="3" maxlength="20" size="20" placeholder="Username" name="username" required/>
       <input type="email" pattern=".+@gmail\.com" placeholder="E-mail" name="email" required/>
       <input type="password" minlength="6" placeholder="Password" name="password" required/>
      <center><button type="submit" class="register-btn" name="register">REGISTER</button></center>  
     </form>
   </div>
 </div>
<!--sign login end-->
<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-1.png) no-repeat">
   <h1>about us</h1>
</div>

<!-- about section starts  -->

<section class="about">
   <div class="content">
      <h3>why choose us?</h3>
      <p>Nurtured from the seed of a single great idea - to empower the traveller - MahaTravel is a pioneer in India’s online travel industry. Founded in the year 2022 by Chavan aditya, MahaTravel came to life to empower the Indian traveller with instant bookings and comprehensive choices. The company initiated its journey serving the travel market offering a range of best-value products and services powered by technology and round-the-clock customer support.
         After consolidating its position in the market as a brand recognised for its reliability and transparency, MahaTravel launched its Maharashtra operations in 2022. With more and more Indians initiating to transact online with IRCTC and new opportunities with the advent of low cost carriers, MahaTravel offered travellers the convenience of booking travel online with a few clicks.</p>
      <div class="icons-container">
         <div class="icons">
            <i class="fas fa-map"></i>
            <span>top destinations</span>
         </div>
         <div class="icons">
            <i class="fas fa-hand-holding-usd"></i>
            <span>affordable price</span>
         </div>
         <div class="icons">
            <i class="fas fa-headset"></i>
            <span>24/7 guide service</span>
         </div>
      </div>
   </div>
   <div class="image">
      <img src="images/about-img.jpg" alt="">
   </div>
</section>

<!-- about section ends -->

<!-- reviews section starts  -->

<section class="reviews">

<h1 class="heading-title"> clients reviews </h1>

   <div class="swiper reviews-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star checked"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Nice experience!<br> One of the best tour up till now. You deserve this 5 stars rating </p>
            <h3>Wane Pushkar </h3>
            <span>traveler</span>
            <img src="images/pic-1.png" alt="">
         </div>

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>It was great and memorable moments Tourist places and planning of itinerary wae well planned</p>
            <h3>Lalwani Dev </h3>
            <span>traveler</span>
            <img src="images/pic-2.png" alt="">
         </div>

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Overall experience was good, hotel accommodation for 3 people was too small than expected. </p>
            <h3>Thorwate Aditya</h3>
            <span>traveler</span>
            <img src="images/pic-3.png" alt="">
         </div>

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Quotation price given much higher side. Driver was busy most of the time in phone calls even during driving</p>
            <h3>Nawde Devarsh</h3>
            <span>traveler</span>
            <img src="images/pic-4.png" alt="">
         </div>

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Houseboat stay was not upto the mark. Could have been better. Reduced 1 star because of houseboat stay experience.</p>
            <h3>Gaikwad Sainath</h3>
            <span>traveler</span>
            <img src="images/pic-5.png" alt="">
         </div>

         <div class="swiper-slide slide">
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>This was a very grate exprience to travel along the 7 wonders of maharashtra with in this price</p>
            <h3>Patait Aadrsh</h3>
            <span>traveler</span>
            <img src="images/pic-6.png" alt="">
         </div>

      </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
   </div>
 
</section>


<!-- reviews section ends -->



<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="question.php"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="policy.php"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="terms.php"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +91 9325713728 </a>
         <a href="#"> <i class="fas fa-phone"></i> +91 8767810998 </a>
         <a href="mailto:"> <i class="fas fa-envelope"></i> adityachavan4142@gmail.com </a>
         <a href="https://www.google.com/maps/place/MGM's+College+Of+Engineering/@19.192287,77.2902639,14z/data=!4m10!1m2!2m1!1sMgm+college!3m6!1s0x3bd1d6fbe138ad81:0x9e88bbe86ec52250!8m2!3d19.1797222!4d77.3242529!15sCgtNZ20gY29sbGVnZVoNIgttZ20gY29sbGVnZZIBB2NvbGxlZ2WaASRDaGREU1VoTk1HOW5TMFZKUTBGblNVTkhhVFpwTlRSUlJSQULgAQA!16s%2Fg%2F1jkx8zyw3"> <i class="fas fa-map"></i> MGM's College Of Eng, Nanded </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://twitter.com/i/flow/login"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="https://www.instagram.com/"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="https://www.linkedin.com/login"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>Aditya.C & Aniket.D</span> | all rights reserved! </div>

</section>

<!-- footer section ends -->









<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js\script.js"></script>

</body>
</html>