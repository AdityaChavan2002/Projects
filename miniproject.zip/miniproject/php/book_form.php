<?php

   $connection = mysqli_connect('localhost','root','','book_db');

   if(isset($_POST['send'])){
      $Fname = $_POST['Fname'];
      $Lname = $_POST['Lname'];
      $email = $_POST['email'];
      $phone = $_POST['phone'];
      $address = $_POST['address'];
      $location1 = $_POST['location1'];
      $location2 = $_POST['location2'];
      $guests = $_POST['guests'];
      $arrivals = $_POST['arrivals'];
      $leaving = $_POST['leaving'];

      $request = " insert into book_form(Fname, Lname, email, phone, address, location1, location2, guests, arrivals, leaving) values('$Fname','$Lname','$email','$phone','$address','$location1','$location2','$guests','$arrivals','$leaving') ";
      mysqli_query($connection, $request);

      header("Location: http://localhost/Miniproject/book.php"); 

   }else{
      echo 'something went wrong please try again!';
   }

?>