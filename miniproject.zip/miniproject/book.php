<?php require('php\connection.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Maha travel - Book</title>
   <!-- web Icon  -->
   <link rel="icon" type="image/x-icon" href="images/India gate logo - small size.png">

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

   <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
   <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.13.2/themes/smoothness/jquery-ui.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.13.2/jquery-ui.min.js"></script>

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="home.php" class="logo"><img width="44" src="images/India gate logo - small size.png" style="margin-left: 3px;">Maha travel&#174;</a>

   <nav class="navbar">
      <a href="home.php">home</a>
      <a href="package.php">package</a>
      <a class="acctive" href="book.php">book</a>
      <a href="about.php">about</a>
<?php
      if(isset($_SESSION['logged_in']) && $_SESSION['logged_in']==true)
      {
         echo"
            <a class='navbar'>
            $_SESSION[username] <a class='fas fa-power-off' style='font-size:26px' href='php\logout.php'></a>
            </a>
            ";
      }
      else
      {
         echo"
            <a class='btn' style='color: aliceblue;' onclick=\"popup('login-popup')\">login</a>
            <a class='btn' style='color: aliceblue;' onclick=\"popup('register-popup')\">sign up</a>
         </nav>
         ";
         
      }
?>
   <div id="menu-btn" class="fas fa-bars"></div>
   </div>
</section>
<!-- header section ends -->

<!--sign login start-->
<div class="popup-container" id="login-popup">
   <div class="popup">
     <form method="POST" action="php\login_register.php">
       <h2>
         <span style="font-size: 2rem;">USER LOGIN</span>
         <button style="font-size: 2rem;" type="reset" class="fas fa-bars fa-times" onclick="popup('login-popup')"></button>
       </h2>
       <input type="text" placeholder="E-mail or Username" name="email_username" required>
       <input type="password" placeholder="Password" name="password" required>
     <center><button type="submit" class="login-btn" name="login">LOGIN</button></center>  
     </form>
   </div>
 </div>

 <div class="popup-container" id="register-popup">
   <div class="register popup">
     <form method="POST" action="php\login_register.php">
       <h2>
         <span style="font-size: 2rem;">USER REGISTER</span>
         <button style="font-size: 2rem;" type="reset" class="fas fa-bars fa-times" onclick="popup('register-popup')"></button>
       </h2>
       <input type="text" pattern="[A-Za-z]{3}" placeholder="Full Name" name="fullname" required/>
       <input type="text" minlength="3" maxlength="20" size="20" placeholder="Username" name="username" required/>
       <input type="email" pattern=".+@gmail\.com" placeholder="E-mail" name="email" required/>
       <input type="password" minlength="6" placeholder="Password" name="password" required/>
      <center><button type="submit" class="register-btn" name="register">REGISTER</button></center>  
     </form>
   </div>
 </div>
<!--sign login end-->
<!-- header section ends -->

<div class="heading" style="background:url(images/header-bg-3.png) no-repeat">
   <h1>book now</h1>
</div>

<!-- booking section starts  -->

<section class="booking">

   <h1 class="heading-title">book your trip!</h1>

   <form action="php\book_form.php" method="POST" class="book-form">

      <div class="flex">
         <div class="inputBox">
            <span>First name :</span>
            <input type="text" pattern="[A-Za-z]{3,10}" title="First name should be at least three character or more" placeholder="enter your first name" name="Fname" required/>
         </div>
         <div class="inputBox">
            <span>Last name :</span>
            <input type="text" pattern="[A-Za-z]{3,10}" title="Last name should be at least three character or more" placeholder="enter your last name" name="Lname" required/>
         </div>
         <div class="inputBox">
            <span>Email :</span>
            <input type="email" pattern=".+@gmail\.com" title="Expected 'gmail.com'" placeholder="enter your email" name="email" required>
         </div>
         <div class="inputBox">
            <span>Phone :</span>
            <input type="tel" placeholder="enter your number" pattern="[0-9]{10}" name="phone" required>
         </div>
         <div class="inputBox">
            <span>Address :</span>
            <input type="text" pattern="[A-Za-z]{3,10}" placeholder="enter your address" name="address" required>
         </div>
         <div class="inputBox">
            <span>From :</span>
            <select type="text" placeholder="enter your address" name="location1" required>
               <option value="">select your address</option>
               <option value="EX-Pune">EX-Pune</option>
               <option value="EX-Mumbai">EX-Mumbai</option>
             </select>
         </div>
         <div class="inputBox">
            <span>Where to :</span>
            <select type="text" placeholder="place you want to visit" name="location2" required>
               <option value="">place you want to visit</option>
               <option value="Seven Wonders Of Maharashtra">Seven Wonders Of Maharashtra</option>
               <option value="Mahabaleshwar - Ratnagiri - Ganpatipule">Mahabaleshwar - Ratnagiri - Ganpatipule</option>
               <option value="Nashik - Shirdi - Ajanta - Ellora">Nashik - Shirdi - Ajanta - Ellora</option>
               <option value="Bhimashankar - Nashik - Ajanta - Ellora">Bhimashankar - Nashik - Ajanta - Ellora</option>
               <option value="Alibaug - Ratnagiri - Ganpatipule">Alibaug - Ratnagiri - Ganpatipule</option>
               <option value="Aurangabad - Ajanta - Ellora - Shirdi">Aurangabad - Ajanta - Ellora - Shirdi</option>
               <option value="Ratnagiri">Ratnagiri</option>
               <option value="Karla Caves (Near Lonavala)">Karla Caves (Near Lonavala)</option>
               <option value="Devagiri / Daulatabad Fort">Devagiri / Daulatabad Fort</option>
               <option value="Sinhagad Fort">Sinhagad Fort</option>
               <option value="Pandavleni Caves (Near Nashik)">Pandavleni Caves (Near Nashik)</option>
               <option value="Kopeshwar Temple (Near Kolhapur)">Kopeshwar Temple (Near Kolhapur)</option>
             </select>
         </div>
         <div class="inputBox">
            <span>How many :</span>
            <input type="number" placeholder="number of guests" min="1" name="guests" required>
         </div>
         <div class="inputBox">
            <span>Arrivals :</span>
            <input type="text" id="from" placeholder="MM/DD/YYYY" required>
         </div>
         <div class="inputBox">
            <span>Departure :</span>
            <input type="text" id="to" placeholder="MM/DD/YYYY" required>
         </div>
      </div>
      <br>
      <center><input type="submit" class="btn" name="send"></center>

   </form>

</section>

<!-- booking section ends -->


<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="question.php"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="policy.php"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="terms.php"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +91 9325713728 </a>
         <a href="#"> <i class="fas fa-phone"></i> +91 8767810998 </a>
         <a href="mailto:"> <i class="fas fa-envelope"></i> adityachavan4142@gmail.com </a>
         <a href="https://www.google.com/maps/place/MGM's+College+Of+Engineering/@19.192287,77.2902639,14z/data=!4m10!1m2!2m1!1sMgm+college!3m6!1s0x3bd1d6fbe138ad81:0x9e88bbe86ec52250!8m2!3d19.1797222!4d77.3242529!15sCgtNZ20gY29sbGVnZVoNIgttZ20gY29sbGVnZZIBB2NvbGxlZ2WaASRDaGREU1VoTk1HOW5TMFZKUTBGblNVTkhhVFpwTlRSUlJSQULgAQA!16s%2Fg%2F1jkx8zyw3"> <i class="fas fa-map"></i> MGM's College Of Eng, Nanded </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://twitter.com/i/flow/login"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="https://www.instagram.com/"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="https://www.linkedin.com/login"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>Aditya.C & Aniket.D</span> | all rights reserved! </div>

</section>

<!-- footer section ends -->









<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<script>
var dateToday = new Date();
var dates = $("#from, #to").datepicker({
    defaultDate: "+1w",
    changeMonth: true,
    numberOfMonths: 3,
    minDate: dateToday,
    onSelect: function(selectedDate) {
        var option = this.id == "from" ? "minDate" : "maxDate",
            instance = $(this).data("datepicker"),
            date = $.datepicker.parseDate(instance.settings.dateFormat || $.datepicker._defaults.dateFormat, selectedDate, instance.settings);
        dates.not(this).datepicker("option", option, date);
    }
});
</script>

</body>
</html>