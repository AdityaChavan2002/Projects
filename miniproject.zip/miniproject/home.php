<?php 
require('php\connection.php'); 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Maha travel - Home</title>
   <!-- web Icon  -->
   <link rel="icon" type="image/x-icon" href="images/India gate logo - small size.png">

   <!-- swiper css link  -->
   <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css">

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   
</head>
<body>
   
<!-- header section -->

<section class="header">
   <div> 
   <a href="home.php" class="logo">
   <img width="44" src="images/India gate logo - small size.png" style="margin-left: 3px;">Maha travel&#174;</a>
   </div>
   <div>
   <nav class="navbar">
      <a class="acctive" href="home.php">home</a>
      <a href="package.php">package</a>
      <a href="book.php">book</a>
      <a href="about.php">about</a>
   
<?php
      if(isset($_SESSION['logged_in']) && $_SESSION['logged_in']==true)
      {
         echo"
         <a class='navbar'> 
            $_SESSION[username] <a class='fas fa-power-off' style='font-size:26px' href='php\logout.php'></a>
            </a>
         ";
      }
      else
      {
         
         echo"
         
            <a class='btn' style='color: aliceblue;' onclick=\"popup('login-popup')\">login</a>
            <a class='btn' style='color: aliceblue;' onclick=\"popup('register-popup')\">sign up</a>
         </nav>
         ";
         
      }
?>
   <div id="menu-btn" class="fas fa-bars"></div>
   </div>
</section>
<!-- header section ends -->

<!--sign login start-->
<div class="popup-container" id="login-popup">
   <div class="popup">
     <form method="POST" action="php\login_register.php">
       <h2>
         <span style="font-size: 2rem;">USER LOGIN</span>
         <button style="font-size: 2rem;" type="reset" class="fas fa-bars fa-times" onclick="popup('login-popup')"></button>
       </h2>
       <input type="text" placeholder="E-mail or Username" name="email_username" required>
       <input type="password" placeholder="Password" name="password" required>
     <center><button type="submit" class="login-btn" name="login">LOGIN</button></center>  
     </form>
   </div>
 </div>

 <div class="popup-container" id="register-popup">
   <div class="register popup">
     <form method="POST" action="php\login_register.php">
       <h2>
         <span style="font-size: 2rem;">USER REGISTER</span>
         <button style="font-size: 2rem;" type="reset" class="fas fa-bars fa-times" onclick="popup('register-popup')"></button>
       </h2>
       <input type="text" pattern="[A-Za-z]{3}" placeholder="Full Name" name="fullname" required/>
       <input type="text" minlength="3" maxlength="20" size="20" placeholder="Username" name="username" required/>
       <input type="email" pattern=".+@gmail\.com" placeholder="E-mail" name="email" required/>
       <input type="password" minlength="6" placeholder="Password" name="password" required/>
      <center><button type="submit" class="register-btn" name="register">REGISTER</button></center>  
     </form>
   </div>
 </div>
<!--sign login end-->

<!-- home section starts  -->
<section class="home">

   <div class="swiper home-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide" style="background:url(images/home-slide-1.jpg) no-repeat">
            <div class="content">
               <span >explore, discover, travel</span>
               <h3>Welcome To Maharashtra</h3>
               <a href="package.php" class="btn">discover more</a>
            </div>
         </div>

         <div class="swiper-slide slide" style="background:url(images/home-slide-2.jpg) no-repeat">
            <div class="content">
               <span>explore, discover, travel</span>
               <h3>discover the new places</h3>
               <a href="package.php" class="btn">discover more</a>
            </div>
         </div>

         <div class="swiper-slide slide" style="background:url(images/home-slide-3.jpg) no-repeat">
            <div class="content">
               <span>explore, discover, travel</span>
               <h3>make your tour worthwhile</h3>
               <a href="package.php" class="btn">discover more</a>
            </div>
         </div>
         
      </div>

      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
   </div>

</section>

<!-- home section ends -->

<!-- services section starts  -->

<section class="services">

   <h1 class="heading-title"> our services </h1>

   <div class="box-container">

      <div class="box">
         <img src="images/icon-1.png" alt="">
         <h3>adventure</h3>
      </div>

      <div class="box">
         <img src="images/icon-2.png" alt="">
         <h3>tour guide</h3>
      </div>

      <div class="box">
         <img src="images/icon-3.png" alt="">
         <h3>trekking</h3>
      </div>

      <div class="box">
         <img src="images/icon-4.png" alt="">
         <h3>camp fire</h3>
      </div>

      <div class="box">
         <img src="images/icon-5.png" alt="">
         <h3>off road</h3>
      </div>

      <div class="box">
         <img src="images/icon-6.png" alt="">
         <h3>camping</h3>
      </div>

   </div>

</section>

<!-- services section ends -->

<!-- home about section starts  -->

<section class="home-about">

   <div class="image">
         <img src="images/about-img.jpg" alt="">
   </div>

   <div class="content">
      <h3>about us</h3><br>
      <p>Nurtured from the seed of a single great idea - to empower the traveller - MahaTravel is a pioneer in India’s online travel industry. Founded in the year 2022 by Chavan aditya, MahaTravel came to life to empower the Indian traveller with instant bookings and comprehensive choices. The company initiated its journey serving the travel market offering a range of best-value products and services powered by technology and round-the-clock customer support.</p>
      <br><br><br>
      <center><a href="about.php" class="btn">read more</a></center>
   </div>

</section>

<!-- home about section ends -->

<!-- home packages section starts  -->

<section class="home-packages">

   <h1 class="heading-title"> our packages </h1>

   <div class="box-container">

      <div class="box">
         <div class="image">
            <img src="images/img-1.jpg" alt="">
         </div>
         <div class="content">
            <h3>Seven Wonders Of Maharashtra</h3>
            <img width="33" src="images/icon+1.png" style="margin-left: 3px;">&emsp;
            <img width="33" src="images/icon+2.png" style="margin-left: 3px;">&emsp;
            <img width="33" src="images/icon+3.png" style="margin-left: 3px;">&emsp;
            <p>
            <h4 style="display:inline-block; text-decoration: line-through; color: #A0A0A0;">₹50000</h4> &emsp;
            <h2 style="display:inline-block;">₹44999 &emsp; 7D/6N</h2>
            </p>
            <a href="z-1wonders.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/img-2.jpg" alt="">
         </div>
         <div class="content">
            <h3>Mahabaleshwar-Ratnagiri (from pune)</h3>
            <img width="33" src="images/icon+1.png" style="margin-left: 3px;">&emsp;
            <img width="33" src="images/icon+2.png" style="margin-left: 3px;">&emsp;
            <img width="33" src="images/icon+3.png" style="margin-left: 3px;">&emsp;
            <p> 
            <h4 style="display:inline-block; text-decoration: line-through; color: #A0A0A0;">₹21000</h4> &emsp;
            <h2 style="display:inline-block;">₹16800 &emsp; 4D/3N</h2>
            </p>
            <a href="z-2Mahabaleshwar.php" class="btn">book now</a>
         </div>
      </div>
      
      <div class="box">
         <div class="image">
            <img src="images/img-3.jpg" alt="">
         </div>
         <div class="content">
            <h3>Nashik-Shirdi-Ajanta-Ellora (from pune)</h3>
            <img width="33" src="images/icon+1.png" style="margin-left: 3px;">&emsp;
            <img width="33" src="images/icon+2.png" style="margin-left: 3px;">&emsp;
            <img width="33" src="images/icon+3.png" style="margin-left: 3px;">&emsp;
            <p>
            <h4 style="display:inline-block; text-decoration: line-through; color: #A0A0A0;">₹16563</h4> &emsp;
            <h2 style="display:inline-block;">₹13250 &emsp; 5D/4N</h2>
            </p>
            <a href="z-3Nashik.php" class="btn">book now</a>
         </div>
      </div>

   </div>

   <div class="load-more"> <a href="package.php" class="btn">load more</a> </div>

</section>

<!-- home packages section ends -->

<!-- home offer section starts  -->

<section class="home-offer">
   <div class="content">
      <h3>upto 50% off</h3>
      <p>Use code</p><div class="code">M-A-H-A-T-R-A-V-E-L-O-F-F</div><p>and get upto 50% off on your first booking</p>
      <a href="book.php" class="btn">book now</a>
   </div>
</section>

<!-- home offer section ends -->

















<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="question.php"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="policy.php"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="terms.php"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +91 9325713728 </a>
         <a href="#"> <i class="fas fa-phone"></i> +91 8767810998 </a>
         <a href="mailto:"> <i class="fas fa-envelope"></i> adityachavan4142@gmail.com </a>
         <a href="https://www.google.com/maps/place/MGM's+College+Of+Engineering/@19.192287,77.2902639,14z/data=!4m10!1m2!2m1!1sMgm+college!3m6!1s0x3bd1d6fbe138ad81:0x9e88bbe86ec52250!8m2!3d19.1797222!4d77.3242529!15sCgtNZ20gY29sbGVnZVoNIgttZ20gY29sbGVnZZIBB2NvbGxlZ2WaASRDaGREU1VoTk1HOW5TMFZKUTBGblNVTkhhVFpwTlRSUlJSQULgAQA!16s%2Fg%2F1jkx8zyw3"> <i class="fas fa-map"></i> MGM's College Of Eng, Nanded </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://twitter.com/i/flow/login"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="https://www.instagram.com/"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="https://www.linkedin.com/login"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>Aditya.C & Aniket.D</span> | all rights reserved! </div>

</section>

<!-- footer section ends -->









<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>