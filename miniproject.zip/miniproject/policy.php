<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Maha travel - Policy</title>
  <!-- web Icon  -->
  <link rel="icon" type="image/x-icon" href="images/India gate logo - small size.png">

  <!-- swiper css link  -->
  <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

  <!-- font awesome cdn link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <!-- custom css file link  -->
  <link rel="stylesheet" href="css/style.css">
  <div class="heading" style="background:url(images/header-bg-3.png) no-repeat">
    <h1>Privacy Policy</h1>
 </div>
</head>
<style>
  .policy{
    padding: 70px;
    font-size: 1.5rem;
  }
</style>
<body>
  <div class="policy">
<p>
    Journey Travel & Tours, is committed to maintaining the privacy of personal information that you provide to us when using the Journey Travel & Tours web site. This Privacy Policy describes how we treat personal information received about you when you visit www.journeytours.com. We may make content or services from other web sites including our co-branded web sites available to you from links located on https://www.journeytours.com. These other web sites are not subject to this Privacy Policy. We recommend that you review the privacy policy at each such web site to determine how that site protects your privacy.
    <br><br><h1>Privacy Policy Promise</h1><br>
    While information is the cornerstone of our ability to provide superior service, our most important asset is our clients’ trust. Keeping client information secure, and using it only as our clients would want us to, is a top priority for all of us at Journey Travel & Tours. Here then, is our promise to our individual customers:
    <ul type="square">
    <li>We will safeguard, according to strict standards of security and confidentiality, any information our customers share with us.</li>
    <li>We will limit the collection and use of customer information to the minimum we require to deliver superior service to our customers, which includes advising our customers about our products, services and other opportunities, and to administer our business.</li>
    <li>We will permit only authorized employees, who are trained in the proper handling of customer information, to have access to that information. Employees who violate our Privacy Promise will be subject to our normal disciplinary process.</li>
    <li>We will not reveal customer information to any external organization unless we have previously informed the customer in disclosures or agreements, or are required by law.</li>
    <li>We will always maintain control over the confidentiality of our customer information. We may, however, share customer information with reputable companies when a customer has expressed an interest in their service or product. Please note that this Privacy Policy does not apply to these other companys use of customer information.</li>
    <li>Whenever we hire other organizations to provide support services, we will require them to conform to our privacy standards and to allow us to audit them for compliance.</li>
    <li>We will attempt to keep customer files complete, up-to-date, and accurate. We will tell our customers how and where to conveniently access their information (except when we’re prohibited by law) and how to notify us about errors which we will promptly correct.</li>
    </ul>
    <br><br><h1>Information We Collect</h1><br>
    <h2>General:</h2>
    When you register, and at other times, we may collect personally identifiable information from you that may include your name, address, telephone number, e-mail address, and facts about your computer. We do not, however, knowingly collect personal information from children under the age of thirteen. In addition, if a user is under 18, unless consent is obtained from your parent/guardian, you are not allowed to provide us with personal information.
    <br><br>
    <h2>Web Site Usage Information:</h2>
    We automatically collect IP addresses and Web site usage information from you when you visit our Web site. This information helps us evaluate how our visitors and customers use and navigate our Web site on an aggregate basis, including the number and frequency of visitors and customers to each Web page, and the length of their visits.
    <br><br><h1>How We Use Information Collected</h1><br>
    We may use information in the following ways:
    For the purposes for which you specifically provided the information.
    To send you e-mail notifications about our new or existing products and services, special offers, or to otherwise contact you.
    To enhance existing features or develop new features, products and services.
    To allow us to personalize the content and advertising that you and others see based on personal characteristics or preferences.
    We may combine the information that we collect from you on https://www.journeytours.com with information that you provide to us in connection with your use of our other products, services and web site.
    We may disclose and use personally identifiable information in special circumstances where it is necessary to enforce our Terms of Use (for example, when necessary to protect our intellectual property rights). We may also disclose or use your personal information when we, in good faith, believe that the law requires us to do so.
    <br><br><h1>Cookies</h1><br>
    We employ cookie technology to help visitors and customers move faster through our site. When you sign on to our Web site or take advantage of several key features, we may pass cookies to your computer. A cookie is a string of information that is sent by a Web site and stored on your hard drive or temporarily in your computer’s memory.
    <br><br><h1>Security</h1><br>
    The personally identifiable information we collect about you is stored in limited access servers. We will maintain safeguards to protect the security of these servers and your personally identifiable information.
    <br><br><h1>Internet-based Transfers</h1><br>
    Given that the Internet is a global environment, using the Internet to collect and process personal data necessarily involves the transmission of data on an international basis. Therefore, by browsing https://www.journeytours.com and communicating electronically with us you acknowledge and agree to our processing of personal data in this way.
    <br><br><h1>Policy Modifications</h1><br>
    We may change this Privacy Policy from time to time. We will post any changes here, so be sure to check back periodically. However, please be assured that if the Privacy Policy changes in the future, we will not use the personal information you have submitted to us under this Privacy Policy in a manner that is materially inconsistent with this Privacy Policy, without your prior consent.
    <br><br><h1>Comments and Questions</h1><br>
    If you have any questions, comments or concerns about our Privacy Policy, please contact us.
</p>
</div>
</body>

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php"> <i class="fas fa-angle-right"></i> home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about</a>
         <a href="package.php"> <i class="fas fa-angle-right"></i> package</a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> book</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="question.php"> <i class="fas fa-angle-right"></i> ask questions</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> about us</a>
         <a href="policy.php"> <i class="fas fa-angle-right"></i> privacy policy</a>
         <a href="terms.php"> <i class="fas fa-angle-right"></i> terms of use</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +91 9325713728 </a>
         <a href="#"> <i class="fas fa-phone"></i> +91 8767810998 </a>
         <a href="mailto:"> <i class="fas fa-envelope"></i> adityachavan4142@gmail.com </a>
         <a href="https://www.google.com/maps/place/MGM's+College+Of+Engineering/@19.192287,77.2902639,14z/data=!4m10!1m2!2m1!1sMgm+college!3m6!1s0x3bd1d6fbe138ad81:0x9e88bbe86ec52250!8m2!3d19.1797222!4d77.3242529!15sCgtNZ20gY29sbGVnZVoNIgttZ20gY29sbGVnZZIBB2NvbGxlZ2WaASRDaGREU1VoTk1HOW5TMFZKUTBGblNVTkhhVFpwTlRSUlJSQULgAQA!16s%2Fg%2F1jkx8zyw3"> <i class="fas fa-map"></i> MGM's College Of Eng, Nanded </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="https://twitter.com/i/flow/login"> <i class="fab fa-twitter"></i> twitter </a>
         <a href="https://www.instagram.com/"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="https://www.linkedin.com/login"> <i class="fab fa-linkedin"></i> linkedin </a>
      </div>

   </div>

   <div class="credit"> created by <span>Aditya.C & Aniket.D</span> | all rights reserved! </div>

</section>

<!-- footer section ends -->









<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>
    </html>